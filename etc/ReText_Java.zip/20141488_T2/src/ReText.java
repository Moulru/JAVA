import java.io.*;
import java.util.*;

public class ReText {
	public static void main(String[] args) throws IOException {
		ArrayList ary = new ArrayList();
		
		try (
			BufferedReader input = new BufferedReader(new FileReader("D:\\test.txt"));
			PrintWriter output = new PrintWriter(new FileWriter("D:\\outputtext.txt"))){
			
			String line;
			int i;
			
			System.out.println("-----입력파일 내용-----");
			// 입력파일 한줄씩 읽어서 화면 출력 + 어레이리스트에 저장
			while ((line = input.readLine()) != null) {
				System.out.println(line + "");
				i = Integer.parseInt(line);
				ary.add(i);
			}
			Collections.sort(ary);
			
			System.out.println("-----출력파일 내용-----");
			// 출력파일 리스트에서 하나씩 뽑아서 작성 + 화면 출력
			for(int j=0; j<ary.size(); j++) {
				output.println(ary.get(j));
				System.out.println(ary.get(j) + "");
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
