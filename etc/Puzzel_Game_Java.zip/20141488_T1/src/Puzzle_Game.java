import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;

public class Puzzle_Game extends JFrame{
	public Puzzle_Game() {
		setTitle("puzzle");
		setSize(500,500);
				
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		
		p1.setLayout(new GridLayout(3,3,0,0));
		
		// 선언
		String[] r = new String[9];
		int[] num = new int[9];
		Random rnd = new Random();
		boolean single = false;
		final String t1 = null;
		final String t2 = null;
		
		// 초기화
		for(int i=0; i<8; i++) {
			num[i] = rnd.nextInt(8)+1;
			for(int j=0; j<i; j++) {
				if(num[i] == num[j]) {
					i--;
					break;
				}
			}
		}
		for(int i=0; i<8; i++) {
			r[i] = String.valueOf(num[i]);
		}
		r[8] = " ";
		
		// 버튼 선언 + 텍스트 넣기
		JButton b1 = new JButton();
		b1.setText(r[0]);
		JButton b2 = new JButton();
		b2.setText(r[1]);
		JButton b3 = new JButton();
		b3.setText(r[2]);
		JButton b4 = new JButton();
		b4.setText(r[3]);
		JButton b5 = new JButton();
		b5.setText(r[4]);
		JButton b6 = new JButton();
		b6.setText(r[5]);
		JButton b7 = new JButton();
		b7.setText(r[6]);
		JButton b8 = new JButton();
		b8.setText(r[7]);
		JButton b9 = new JButton();
		b9.setText(r[8]);
		
		// 버튼 리스너 (위치 바꾸기)
		b1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b2.getText().equals(" ")) {
					b2.setText(b1.getText());
					b1.setText(" ");
				}
				if(b4.getText().equals(" ")) {
					b4.setText(b1.getText());
					b1.setText(" ");
				}
			}
		});
		
		b2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b3.getText().equals(" ")) {
					b3.setText(b2.getText());
					b2.setText(" ");
				}
				if(b1.getText().equals(" ")) {
					b1.setText(b2.getText());
					b2.setText(" ");
				}
				if(b5.getText().equals(" ")) {
					b5.setText(b2.getText());
					b2.setText(" ");
				}
			}
		});
		
		b3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b2.getText().equals(" ")) {
					b2.setText(b3.getText());
					b3.setText(" ");
				}
				if(b6.getText().equals(" ")) {
					b6.setText(b3.getText());
					b3.setText(" ");
				}
			}
		});
		
		b4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b1.getText().equals(" ")) {
					b1.setText(b4.getText());
					b4.setText(" ");
				}
				if(b5.getText().equals(" ")) {
					b5.setText(b4.getText());
					b4.setText(" ");
				}
				if(b7.getText().equals(" ")) {
					b7.setText(b4.getText());
					b4.setText(" ");
				}
			}
		});
		
		b5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b2.getText().equals(" ")) {
					b2.setText(b5.getText());
					b5.setText(" ");
				}
				if(b4.getText().equals(" ")) {
					b4.setText(b5.getText());
					b5.setText(" ");
				}
				if(b6.getText().equals(" ")) {
					b6.setText(b5.getText());
					b5.setText(" ");
				}
				if(b8.getText().equals(" ")) {
					b8.setText(b5.getText());
					b5.setText(" ");
				}
			}
		});
		
		b6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b3.getText().equals(" ")) {
					b3.setText(b6.getText());
					b6.setText(" ");
				}
				if(b5.getText().equals(" ")) {
					b5.setText(b6.getText());
					b6.setText(" ");
				}
				if(b9.getText().equals(" ")) {
					b9.setText(b6.getText());
					b6.setText(" ");
				}
			}
		});
		
		b7.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b4.getText().equals(" ")) {
					b4.setText(b7.getText());
					b7.setText(" ");
				}
				if(b8.getText().equals(" ")) {
					b8.setText(b7.getText());
					b7.setText(" ");
				}
			}
		});
		
		b8.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b9.getText().equals(" ")) {
					b9.setText(b8.getText());
					b8.setText(" ");
				}
				if(b5.getText().equals(" ")) {
					b5.setText(b8.getText());
					b8.setText(" ");
				}
				if(b7.getText().equals(" ")) {
					b7.setText(b8.getText());
					b8.setText(" ");
				}
			}
		});
		
		b9.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(b8.getText().equals(" ")) {
					b8.setText(b9.getText());
					b9.setText(" ");
				}
				if(b6.getText().equals(" ")) {
					b6.setText(b9.getText());
					b9.setText(" ");
				}
			}
		});
		
		p1.add(b1);
		p1.add(b2);
		p1.add(b3);
		p1.add(b4);
		p1.add(b5);
		p1.add(b6);
		p1.add(b7);
		p1.add(b8);
		p1.add(b9);
		
		p2.setLayout(new GridLayout(1,1,0,0));
		JButton reset = new JButton("reset");
		
		// 버튼 리스너 (초기화)
		reset.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for(int i=0; i<8; i++) {
					num[i] = rnd.nextInt(8)+1;
					for(int j=0; j<i; j++) {
						if(num[i] == num[j]) {
							i--;
							break;
						}
					}
				}
				for(int i=0; i<8; i++) {
					r[i] = String.valueOf(num[i]);
				}
				r[8] = " ";
				
				b1.setText(r[0]);
				b2.setText(r[1]);
				b3.setText(r[2]);
				b4.setText(r[3]);
				b5.setText(r[4]);
				b6.setText(r[5]);
				b7.setText(r[6]);
				b8.setText(r[7]);
				b9.setText(r[8]);
			}
		});
		
		p2.add(reset);
		
		p.add(p1, BorderLayout.CENTER);
		p.add(p2, BorderLayout.SOUTH);
		
		add(p);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args) {
		Puzzle_Game frame = new Puzzle_Game();
	}
}